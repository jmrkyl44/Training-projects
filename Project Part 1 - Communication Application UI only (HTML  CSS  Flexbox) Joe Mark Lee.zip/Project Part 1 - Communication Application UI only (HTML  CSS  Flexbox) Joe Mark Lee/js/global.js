function toggleModal(id) {
    var element = document.getElementById(id);
    if (element.style.display === "block") {
        element.style.display = "none";
    } else {
        element.style.display = "block";
    }
}

function showDelete() {
    toggleModal("showDelete");
}

function hideDelete() {
    toggleModal("showDelete");
}

function showEditLabel() {
    toggleModal("showEditLabel");
}

function hideEditLabel() {
    toggleModal("showEditLabel");
}

function showUpload() {
    toggleModal("showUpload");
}

function hideUpload() {
    toggleModal("showUpload");
}
